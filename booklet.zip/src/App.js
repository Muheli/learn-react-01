import React, { useState } from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./index.css";
import { withObject, Loading, Button } from "@varius.io/react-view-sdk";
import Slider from "react-slick";
import styled from "@emotion/styled";
import Mustache from 'mustache';

const PrevArrow = ({ arrowType, className, onClick, arrowColor, getColor, currentSlide, lastSlide }) => currentSlide !==  0 && <i className={className + " fal fa-angle-left"} onClick={onClick} style={{lineHeight:0,color:getColor(arrowColor), display:arrowType !== 'chevron' ? 'none' : 'inherit'}}/>;
const NextArrow = ({ arrowType, className, onClick, arrowColor, getColor, currentSlide, lastSlide }) => currentSlide !== lastSlide && <i className={className + " fal fa-angle-right"} onClick={onClick} style={{lineHeight:0,color:getColor(arrowColor), display:arrowType !== 'chevron' ? 'none' : 'inherit'}}/>;

const actionHandler = {
	"openAr": "viewer.ar.show",
	"closeVatom": "viewer.view.close",
	"openMap": "viewer.map.show",
	"url": "viewer.url.open",
	"openCamera": "viewer.scanner.show",
	"openSend": "viewer.action.send",
}

const StyledArrow = styled.div`
	display: block;
	z-index: 3;
	top: ${({ position }) => position};
	&:before {
		${({ arrowType }) => arrowType.arrowType === 'chevron' && 'content:"" !important;'}
		font-size: ${({ arrowWidth }) => `${arrowWidth.value}px !important`};
		color: ${({ arrowColor, getColor }) => `${getColor(arrowColor)} !important`};
	}
`;

const ButtonContainer = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100vw;
	position: absolute;
	bottom: ${({ nudge }) => `${nudge.y}%`};
`;

const Dot = styled.div`
    width: 8px;
    height: 8px;
    content: "•";
    text-align: center;
	background-color: ${({ color }) => color};
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
	opacity: ${({ isSelected }) => isSelected ? 1 : 0.5};
`;

const DotContainer = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	height: 100%;
`;

const renderChildren = (resources, firstButton, secondButton, thirdButton, thirdButtonPage) => {
	let slides = [];
	for (let i in resources) {
		if (i !== "arrowPosition") slides.push(resources[i].ref);
	}
	const lastSlide = resources.length - 1;
	return slides.map((image, i) => {
		return (
			<div key={i} style={{ borderRadius: 8 }}>
				<img
					alt=""
					src={image}
					style={{ height: "100%", width: "100%" }}
				/>
				{i === 0 && firstButton !== null &&
					<ButtonContainer nudge={firstButton.nudge}>
						<Button
							{...firstButton}
						>
							{firstButton.text}
						</Button>
					</ButtonContainer>
				}
				{i === lastSlide && lastSlide !== 0 && secondButton !== null &&
					<ButtonContainer nudge={secondButton.nudge}>
						<Button
							{...secondButton}
						>
							{secondButton.text}
						</Button>
					</ButtonContainer>
				}
				{i === thirdButtonPage - 1 && thirdButton !== null &&
					<ButtonContainer nudge={thirdButton.nudge}>
						<Button
							{...thirdButton}
						>
							{thirdButton.text}
						</Button>
					</ButtonContainer>
				}
			</div>
		)

	});
}

const App = ({
	isLoading,
	viewArgs,
	getColor,
	interactWithViewer,
	object,
	businessId,
}) => {
	const [currentSlide, setCurrentSlide] = useState(0)
	if (isLoading) {
		return <Loading alt="loading" />
	}

	const {
		arrowNudge,
		dotNudge,
		arrowType,
		arrowWidth,
		arrowColor,
		dotColor,
		cardImages,
		button1,
		button2,
		button3,
		button1Style,
		button2Style,
		button3Style,
		button1Nudge,
		button2Nudge,
		button3Nudge,
		button1Action,
		button2Action,
		button3Action,
		button3Page,
	} = viewArgs;

	const settings = {
		arrows: true,
		dots: true,
		infinite: false,
		speed: 500,
		slidesToShow: 1,
		slidesToScroll: 1,
		centerPadding: "0px",
		centerMode: true,
		prevArrow: <StyledArrow getColor={getColor} arrowColor={arrowColor} arrowWidth={arrowWidth} position={`${100 - arrowNudge.y}${arrowNudge.unit}`} arrowType={{arrowType}}><PrevArrow arrowType={arrowType} arrowColor={arrowColor} getColor={getColor} currentSlide={currentSlide} lastSlide={cardImages.length -1}/></StyledArrow>,
		nextArrow: <StyledArrow getColor={getColor} arrowColor={arrowColor} arrowWidth={arrowWidth} position={`${100 - arrowNudge.y}${arrowNudge.unit}`} arrowType={{arrowType}}><NextArrow arrowType={arrowType} arrowColor={arrowColor} getColor={getColor} currentSlide={currentSlide} lastSlide={cardImages.length -1}/></StyledArrow>,
		beforeChange: (prev, next) => setCurrentSlide(next),
		appendDots: dots => <ul style={{ display: 'block', position: 'absolute', bottom: `${dotNudge.y}${dotNudge.unit}` }}>{dots}</ul>,
		customPaging: i => (
			<DotContainer>
				<Dot isSelected={currentSlide === i} color={getColor(arrowColor)} key={i} />
			</DotContainer>
		)
	};

	let button1Design = null;
	let button2Design = null;
	let button3Design = null;

	if (button1.toggled) {
		const onClick = () => {
			if (button1Action) {
				const { type, url } = button1Action
				if (type === "url") {
					interactWithViewer(actionHandler[type], { url });
				} else if (actionHandler[type]) {
					interactWithViewer(actionHandler[type]);
				} else {
					console.log(`[View Error]: Unable to perform user action of type: ${type}`);
				}
			} else {
				// hack for coke demo
				interactWithViewer('viewer.action.send');
			}
		}

		const variables = {
			vatomId: object.id || 1234,
		}

		let text = ""

		try {
			text = Mustache.render(button1.text, variables);
		} catch(e) {
			text = button1.text
		}

		button1Design = {
			text,
			onClick,
			style: button1Style,
			businessId,
			nudge: button1Nudge,
		}
	}

	if (button2.toggled) {
		const onClick = () => {
			const { type, url } = button2Action
			if (type === "url") {
				interactWithViewer(actionHandler[type], { url });
			} else if (actionHandler[type]) {
				interactWithViewer(actionHandler[type]);
			} else {
				console.log(`[View Error]: Unable to perform user action of type: ${type}`);
			}
		}

		const variables = {
			vatomId: object.id || 1234
		}

		let text = ""

		try {
			text = Mustache.render(button2.text, variables);
		} catch(e) {
			text = button2.text
		}
		button2Design = {
			text,
			onClick,
			style: button2Style,
			businessId,
			nudge: button2Nudge,
		}
	}

	if (button3.toggled) {
		const onClick = () => {
			const { type, url } = button3Action
			if (type === "url") {
				interactWithViewer(actionHandler[type], { url });
			} else if (actionHandler[type]) {
				interactWithViewer(actionHandler[type]);
			} else {
				console.log(`[View Error]: Unable to perform user action of type: ${type}`);
			}
		}

		const variables = {
			vatomId: object.id || 1234
		}

		let text = ""

		try {
			text = Mustache.render(button3.text, variables);
		} catch(e) {
			text = button3.text
		}
		button3Design = {
			text,
			onClick,
			style: button3Style,
			businessId,
			nudge: button3Nudge,
		}
	}

	if (cardImages.length === 1) {
		return (
			<div style={{ width: '100%', height: "100%" }}>
				<img
					alt=""
					src={cardImages[0].ref}
					style={{ width: '100%', height: "100%", borderradius: 8 }}
				/>
				{button1.toggled &&
					<ButtonContainer nudge={button1Design.nudge}>
						<Button
							{...button1Design}
						>
							{button1Design.text}
						</Button>
					</ButtonContainer>
				}
			</div>
		);
	}

	return (
		<Slider style={{ overflow: "hidden" }} {...settings}>
			{renderChildren(cardImages, button1Design, button2Design, button3Design, button3Page)}
		</Slider>
	);
}

export default withObject(App);
