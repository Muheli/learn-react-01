info booklet v2 -

includes style component & optional button on first & last pages